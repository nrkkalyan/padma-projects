using System;

namespace BetygKalkylatorn
{
	public class BankLoan
	{
		private decimal belopp;
		private int     antalAr;
		private double  r�nta;

		//Konstruktor utan param.
		//S�tt n�gra defaultv�rden
		public BankLoan()
		{
			belopp = 0.0M;
			antalAr = 5;
			r�nta =  3.50;
		}
	
		//Konstruktor med 1 param.
		public BankLoan(decimal amount)
		{
			belopp = amount;//inparam fr�n klientklass
			antalAr = 5;    //default v�rde
			r�nta =  3.50;  //default v�rde
		}
		//Konstruktor med 2 param.
		public BankLoan(decimal amount, int �r)
		{
			belopp = amount;		//inparam fr�n klientklass
			antalAr = �r;			//inparam fr�n klientklass
			this.r�nta =  3.50;		//default v�rde
		}

		//Konstruktor med 3 param, olika typer.
		public BankLoan(long amount,int �r, double r�nta): this((decimal)amount, �r)
		{
			this.r�nta =  r�nta;
		}

/*
		//Konstruktor med 3 param, olika typer.
		public BankLoan(long amount,int �r, double r�nta)
		{
			belopp = amount;		//inparam fr�n klientklass
			antalAr = �r;			//inparam fr�n klientklass
			this.r�nta =  r�nta;	//inparam fr�n klientklass
		}
*/
		//... andra metoder

		public override string ToString()
		{
			return String.Format("{0, 15:c}\n{1,15}\n{2,15}%",
				belopp, antalAr, r�nta);
		}


		//destruktorn
		~BankLoan()
		{
		}

	} //klass



	public class CarLoan : BankLoan
	{
		private const int maxYears = 10;
	
		public CarLoan (decimal amount): base( amount )
		{
		}
		public override string ToString()
		{
			return base.ToString ();
		}

		//...
	}



}
