/* 
 * 
 * input.cs
 * Created by:  Farid Naisan, 2007-02-xx
 * Revised by:  Farid Naisan, 2007-03-19, minor corrections made.
 * 
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

//Note:  The class is not put into a namespace in order to include it in other projects without
//any changes.


//type and range of a requested number 
public enum NumberType
{
	PositiveWithZero,
	PositiveNoZero,
	NegativeWithZero,
	NegativeNoZero,
	PositiveAndNegativeWithZero,  //all numbers
	PositiveAndNegativeNoZero
}


//The class Input is a simple class that handles conversion of a string to a corresponding number.
//The number is then valid only if it is within a the range of a given NumberType
//The class, together with the above enum, should actually be placed in some type av a common utility library (DLL).
public class Input
{
	//Changes a string to a double; the result is saved and sent to the caller in numOut
	//It returns true if everything is OK and false otherwise
	public static bool GetDouble(string strIn, NumberType numType, out double numOut)
	{
		if (double.TryParse(strIn, out numOut))
		{
			switch (numType)
			{
				case NumberType.PositiveWithZero:
					return (numOut >= 0.0);
				case NumberType.PositiveNoZero:
					return (numOut > 0.0);
				case NumberType.NegativeWithZero:
					return (numOut >= 0.0);
				case NumberType.NegativeNoZero:
					return (numOut < 0);
				case NumberType.PositiveAndNegativeWithZero:
					return true;
				case NumberType.PositiveAndNegativeNoZero:
					return (Math.Round(numOut, 8) != 0.0);
			}
			Debug.Assert(false); //Execution should never come here
			return false;
		}
		else
			return false;  //string is not a number

	}

	//Overloaded fuction GetDouble that changes a string to a double and checks if it beween a max and
	//min values
	public static bool GetDouble(string strIn, double minValue, double maxValue, out double numOut)
	{
		if (double.TryParse(strIn, out numOut)) //all numbers allowed
			return ((numOut >= minValue) && (numOut <= maxValue));
		else
			return false;
	}

	//Although in C# 2.0 there is int.TryParse (did not exist in earlier versions),
	//the aboove GetDouble is reused to save some programming lines in connection 
	//with checking the range of value type.
	public static bool GetInteger(string strIn, NumberType numType, out int numOut)
	{
		double dblvalue = 0.0;
		bool bOK = GetDouble(strIn, numType, out dblvalue);
		numOut = (int)dblvalue;
		return bOK;
	}


	public static bool GetInteger(string strIn, int minValue, int maxValue, out int numOut)
	{
		if (int.TryParse(strIn, out numOut))  //all numbers allowed
			return ((numOut >= minValue) && (numOut <= maxValue));
		else
			return false;
	}
}
