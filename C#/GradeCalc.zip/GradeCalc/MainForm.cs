//frmMain.cs
//Created: 2005-10-27, Farid Naisan
//Revised: 2006-03-11, Farid Naisan



using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;//f�r kulturspecifika data som datum osv


namespace GradeCalculator
{
	/// <summary>
	/// Summary description for FrmMain.
	/// </summary>
	public class FrmMain : System.Windows.Forms.Form
	{
		#region WindowsStuffHiddenByNisse
		internal System.Windows.Forms.GroupBox grpgrade;
		internal System.Windows.Forms.Label lblgrade;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.TextBox txtpoints;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.Button btnOK;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.TextBox txtName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.grpgrade = new System.Windows.Forms.GroupBox();
            this.lblgrade = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtpoints = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.grpgrade.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpgrade
            // 
            this.grpgrade.Controls.Add(this.lblgrade);
            this.grpgrade.Controls.Add(this.Label3);
            this.grpgrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpgrade.Location = new System.Drawing.Point(20, 153);
            this.grpgrade.Name = "grpgrade";
            this.grpgrade.Size = new System.Drawing.Size(380, 97);
            this.grpgrade.TabIndex = 11;
            this.grpgrade.TabStop = false;
            this.grpgrade.Text = "GroupBox1";
            this.grpgrade.Enter += new System.EventHandler(this.grpgrade_Enter);
            // 
            // lblgrade
            // 
            this.lblgrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblgrade.Location = new System.Drawing.Point(93, 28);
            this.lblgrade.Name = "lblgrade";
            this.lblgrade.Size = new System.Drawing.Size(277, 27);
            this.lblgrade.TabIndex = 2;
            this.lblgrade.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label3
            // 
            this.Label3.Location = new System.Drawing.Point(20, 35);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(70, 20);
            this.Label3.TabIndex = 0;
            this.Label3.Text = "Grade";
            // 
            // txtpoints
            // 
            this.txtpoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpoints.Location = new System.Drawing.Point(327, 55);
            this.txtpoints.Name = "txtpoints";
            this.txtpoints.Size = new System.Drawing.Size(73, 23);
            this.txtpoints.TabIndex = 10;
            this.txtpoints.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpoints.TextChanged += new System.EventHandler(this.txtpoints_TextChanged);
            // 
            // Label2
            // 
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(13, 55);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(94, 21);
            this.Label2.TabIndex = 9;
            this.Label2.Text = "points";
            this.Label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(138, 104);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(136, 40);
            this.btnOK.TabIndex = 8;
            this.btnOK.Text = "OK";
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // Label1
            // 
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(13, 21);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(107, 21);
            this.Label1.TabIndex = 7;
            this.Label1.Text = "Name";
            this.Label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(140, 21);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(260, 23);
            this.txtName.TabIndex = 6;
            this.txtName.TextChanged += new System.EventHandler(this.txtNamn_TextChanged);
            // 
            // FrmMain
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(424, 280);
            this.Controls.Add(this.grpgrade);
            this.Controls.Add(this.txtpoints);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.txtName);
            this.Name = "FrmMain";
            this.Text = "Grade Calcylator";
            this.grpgrade.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new FrmMain());
		}
		#endregion
		public FrmMain()
		{
			InitializeComponent();
			InitiateControls();
		}

		//-------------------------------------------------------------------------
		//  Nisse's code

		//instance fields - none
		

		//Methods

		private void btnOK_Click(object sender, System.EventArgs e)
		{
			Processagrade();
		}
		private void Processagrade()
		{

			//controls if a text is convertable to a double
			double points = 0.0;
			
			if (Input.GetDouble(txtpoints.Text,0.0, 60.0, out points) )
			{
				GradeCalc grade = new GradeCalc(points);  //create an instance of GradeCalc (aggregation)
				string strNamn = txtName.Text.Trim(); //Delete extra spaces from ends of the name

				if (strNamn == String.Empty)
					strNamn = "Nisse";

				grpgrade.Text = strNamn;

				if ( grade.Checkpoints())
					lblgrade.Text = grade.ToString();
				else
					MessageBox.Show(grade.ErrorMessage, "Invalid Input!");
			}   
			else
				MessageBox.Show("Incomplete input", "Invalid Input!");
		}

		//Clear input/output controls
		private void InitiateControls()
		{
			txtName.Text = "";
			txtpoints.Text = "";
			lblgrade.Text = "";
			grpgrade.Text = "";
		}

		//This method is an event handler to the txtName control.  It is automatically
		//called everytime any change occurrs in the textbox, liken when the user writes
		//or deletes a text in the box.
		private void txtNamn_TextChanged(object sender, System.EventArgs e)
		{
			UpdateGUI();	
		}

		//Updates the groupbox with the name of the person
		private void UpdateGUI()
		{
			grpgrade.Text = String.Format("{0}- {1} points", txtName.Text, txtpoints.Text);
			lblgrade.Text = "";
		}


		//Event-handler for the textbox txtPoints.
		private void txtpoints_TextChanged(object sender, System.EventArgs e)
		{
			UpdateGUI();
		}
        
	}//class
}//namespace