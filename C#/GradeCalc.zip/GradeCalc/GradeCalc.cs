//GradeCalculator.cs
//Farid Naisan: 2006-10-16
//Modified :2007-04-01, Grade A, B, C, F instead of 3,4,5
//Write a program that converts points received in a
//exam to grades. The maximum points is 60 and the grades
//are in a scale 1-5


using System;

namespace GradeCalculator
{
	//This class calculates the grade 1 to 5 for a given number of 
	//points 0-100

	public class GradeCalc
	{
		private const int lowLimit= 0;  //negativa points accepteras inte
		private const int highLimit= 60; //max 60 points

		private double points;  //points from an exam
		private string errorMessage;
		
		//A constructor is used for creating an object with initial values
		//A default constructor is one that has no parameters
		//A constuctor is usually used for initiations. 
		public GradeCalc()  //default constructor
		{
			points = 0;
			errorMessage = String.Empty;
		}

		//Constructor with one parameter
		//this constructor creates the object with an initial value for 
		//points
		public GradeCalc( double points)
		{
			this.points = points;
		}

		//A property makes provides a way to retrieve a value from a 
		//a private field (get) or change a value to the private field.
		//Access to the variable points is provided by the following
		//property.
		public double Points  //note that points and Points are different names
		{
			get { return points;}
			set 
			{
				if (Checkpoints())
					points = value;  //value is a datatype that 
				                     //automaticall changes type to the property, here a double
			}
		}

		//Readonly property for errorMessage.  Client class 
		//are not allowed to change the message, that why no set
		//property is written
		public string ErrorMessage
		{
			get {return errorMessage;}
		}



		//Control the validity of the a given point
		public bool Checkpoints()
		{
			if ( (points <= highLimit) && (points >= lowLimit))
			{
				return true;
			}
			else
			{
				errorMessage = String.Format("The value of the points is invalid. It should between {0} and {1}",
					lowLimit,highLimit);
					return false;
			}
		}

		//Convert points to grades 1- 5
		public char PointsToGrade(out string gradeText)
		{
			char rank = 'X';  //initiation
			gradeText = "Failed"; //initiation


			if (points > 60.00)
			{
				gradeText = "Undefined!";
			}
			else if ((points > 50.00) && (points <= 60.00))  //51-60
			{
				gradeText = "with distinction Passed";
				rank = 'A';
			}
			else if ((points > 40.00) && (points <= 50.00)) //41-50
			{
				gradeText = "Well Passed";
				rank = 'B';
			}
			else if ((points >= 30.00) && (points <= 40.00))  //30-40
			{
				gradeText = "Passed";
				rank = 'C';
			}
			else if ((points > 20.00) && (points < 30.00))  //21- 29 
				rank = 'D';
			else if ((points > 10.00) && (points < 20.00))  //11-19
				rank = 'E';
			else
				rank = 'F'; //0-10

			return rank;
		}

		//All objects inherit from a Super object called 
		//jst Object (or object). This super object has som methods 
		//that can be "rewritten".  The process is called "overriding".
		//We override the ToString, a method that commonly used to 
		//supply text information about the object.
		public override string ToString()
		{
			string strGrade;

			char gradeChar = PointsToGrade(out strGrade);
			return String.Format("Grade {0},  {1}", gradeChar, strGrade);
		}
	}
}
